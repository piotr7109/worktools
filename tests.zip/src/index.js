import {render} from 'react-dom';
import {Provider} from 'react-redux';
import React from 'react';
import Counter from './containers/CounterConnector';
import Status from './containers/StatusConnector';
import Articles from './containers/ArticlesConnector';
import store from './store/store';

import {Map} from 'immutable';
/*
 render(
 <Provider store={store}>
 <div>
 <Counter />
 <Status />
 <Articles />
 </div>
 </Provider>
 , document.getElementById('root')
 );
 */
function dirReduce(arr) {
  const result = arr.map(i => i);
  const remove = dir => result.includes(dir) && (result.splice(result.indexOf(dir), 1));

  arr.forEach(item => (
    {
      ['NORTH']: () => remove('SOUTH'),
      ['SOUTH']: () => remove('NORTH'),
      ['WEST']: () => remove('EAST'),
      ['EAST']: () => remove('WEST')
    }[item]()
  ));

  return result;
}

console.log(dirReduce(['NORTH', 'SOUTH', 'EAST', 'WEST', 'NORTH', 'SOUTH', 'NORTH', 'NORTH', 'NORTH', 'WEST', 'EAST', 'NORTH', 'SOUTH', 'WEST', 'EAST']));