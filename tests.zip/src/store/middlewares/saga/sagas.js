import fetch from 'isomorphic-fetch';
import {delay} from 'redux-saga';
import {put, takeEvery, takeLatest, call} from 'redux-saga/effects'
import {INCREMENT_ASYNC, INCREMENT} from '../../../modules/counter/actions'

import {GET_DATA_REQUESTED, GET_DATA_DONE, GET_DATA_FAILED} from './../../../modules/articles/actions';

export function* getArticles() {
  try {
    const response = yield call(fetch, 'http://localhost:8100/articles.json');
    const data = yield response.json();

    yield put(GET_DATA_DONE(data));
  } catch (e) {
    yield put(GET_DATA_FAILED(e));
  }
}

export function* getArticlesSaga() {
  yield takeLatest(GET_DATA_REQUESTED, getArticles);
}

export function* incrementAsync() {
  yield delay(1000);
  yield put(INCREMENT());
}

// Our watcher Saga: spawn a new incrementAsync task on each INCREMENT_ASYNC
export function* watchIncrementAsync() {
  yield takeEvery(INCREMENT_ASYNC, incrementAsync);
}