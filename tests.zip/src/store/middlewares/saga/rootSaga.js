import {getArticlesSaga, watchIncrementAsync} from './sagas';

export default function* rootSaga() {
  yield [
    getArticlesSaga(),
    watchIncrementAsync()
  ];
}