import {combineReducers, createStore, applyMiddleware, compose} from 'redux';
import createSagaMiddleware from 'redux-saga';

import rootSaga from './middlewares/saga/rootSaga';
import logger from './middlewares/logger/logger';

import {reducer as counterReducer} from '../modules/counter/reducer';
import {reducer as statusReducer} from '../modules/status/reducer';
import {reducer as articlesReducer} from '../modules/articles/reducer';

const sagaMiddleware = createSagaMiddleware();

const store = createStore(
  combineReducers({counterReducer, statusReducer, articlesReducer}),
  {},
  compose(
    applyMiddleware(sagaMiddleware),
    window.devToolsExtension ? window.devToolsExtension() : f => f
  )
);

sagaMiddleware.run(rootSaga);

export default store;