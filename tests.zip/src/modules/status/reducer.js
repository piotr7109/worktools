import {Map} from 'immutable';
import {handleActions} from 'redux-actions';
import * as ACTIONS from './actions';

export const reducer = handleActions({
  [ACTIONS.TOGGLE_STATUS]: state => state.set('toggled', !state.get('toggled'))
}, Map({toggled: false}));