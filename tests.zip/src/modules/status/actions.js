import { createAction } from 'redux-actions';

export const TOGGLE_STATUS = createAction('TOGGLE_STATUS', () => null);