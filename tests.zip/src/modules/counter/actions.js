import { createAction } from 'redux-actions';

export const INCREMENT = createAction('INCREMENT', () => null);
export const INCREMENT_ASYNC = createAction('INCREMENT_ASYNC', () => null);
export const DECREMENT = createAction('DECREMENT', () => null);