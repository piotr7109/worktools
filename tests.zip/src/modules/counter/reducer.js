import { Map } from 'immutable';
import { handleActions } from 'redux-actions';
import * as ACTIONS from './actions';

export const reducer = handleActions({
    [ACTIONS.INCREMENT]: state => state.set('counter', state.get('counter') + 1),
    [ACTIONS.DECREMENT]: state => state.set('counter', state.get('counter') - 1)
}, Map({ counter: 0 }));
