import { Map } from 'immutable';
import { handleActions } from 'redux-actions';
import * as ACTIONS from './actions';

export const reducer = handleActions({
    
}, Map());
