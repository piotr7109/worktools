import {createSelector} from 'reselect';

export const getLoadingStatus = state => state.articlesReducer.get('loadingStatus');

export const getArticles = state => state.articlesReducer.get('articles');

export const getFilteredCars = createSelector(
  [
    getArticles,
    state => getTextFilters(state),
    state => getFilter(state, 'max_amount'),
    state => getFilter(state, 'min_amount')
  ],
  (cars, filters, maxAmount, minAmount) => {
    return filters
      .reduce((filteredCars, filter) => filteredCars.filter(getTextFilterCallback(filter)), cars)
      .filter(car => !maxAmount || car.get('price') <= +maxAmount)
      .filter(car => !minAmount || car.get('price') >= +minAmount)
  }
);

const getFilter = (state, filterName) => state.articlesReducer.get('filters').get(filterName);

const getTextFilterCallback = filter => car => ~car.get(filter.name).search(new RegExp(filter.value, 'i'));

function getTextFilters(state) {
  const filters = state.articlesReducer.get('filters'),
    filtersNames = ['manufacturer', 'color'];//filters.keySeq().toArray();

  return filtersNames.map(filterName => ({name: filterName, value: filters.get(filterName)}));
}