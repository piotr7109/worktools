import { createAction } from 'redux-actions';

export const GET_DATA_REQUESTED = createAction('GET_DATA_REQUESTED', () => null);
export const GET_DATA_DONE = createAction('GET_DATA_DONE', data => data);
export const GET_DATA_FAILED = createAction('GET_DATA_FAILED', e => e);

export const CLEAR_FILTERS = createAction('CLEAR_FILTERS', () => null);
export const SET_FILTERS = createAction('SET_FILTERS', filter => filter);