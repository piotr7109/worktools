import {Map, List, fromJS} from 'immutable';
import {handleActions} from 'redux-actions';
import {LOADING_DONE, LOADING_FAILED, LOADING_IN_PROGRESS} from '../../constants';
import * as ACTIONS from './actions';
import * as articles from './selectors';

export const reducer = handleActions({
  [ACTIONS.GET_DATA_REQUESTED]: state =>
    state
      .set('articles', List())
      .set('loadingStatus', LOADING_IN_PROGRESS),
  [ACTIONS.GET_DATA_DONE]: (state, {payload}) =>
    state
      .set('articles', fromJS(payload))
      .set('loadingStatus', LOADING_DONE),
  [ACTIONS.GET_DATA_FAILED]: (state, {payload}) =>
    state
      .set('articles', List())
      .set('loadingStatus', LOADING_FAILED),
  [ACTIONS.SET_FILTERS]: (state, {payload}) => state.set('filters', fromJS(payload)),
  [ACTIONS.CLEAR_FILTERS]: state => state.set('filters', Map())
}, fromJS({articles: [], filters: {}, loadingStatus: ''}));
