import { connect } from 'react-redux';
import Status from '../components/Status';
import * as status from '../modules/status/selectors';
import mapDispatchToProps from '../mapDispatchToProps';

const mapStateToProps = state => ({
    toggled: status.getToggled(state)
});

export default connect(mapStateToProps, mapDispatchToProps)(Status);