import { connect } from 'react-redux';
import Counter from '../components/Counter';
import * as counter from '../modules/counter/selectors';
import mapDispatchToProps from '../mapDispatchToProps';

const mapStateToProps = state => ({
    counter: counter.getCounter(state)
});

export default connect(mapStateToProps, mapDispatchToProps)(Counter);