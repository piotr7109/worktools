import { connect } from 'react-redux';
import Articles from '../components/Articles';
import * as articles from '../modules/articles/selectors';
import mapDispatchToProps from '../mapDispatchToProps';

const mapStateToProps = state => ({
    loadingStatus: articles.getLoadingStatus(state),
    articles: articles.getFilteredCars(state)
});

export default connect(mapStateToProps, mapDispatchToProps)(Articles);