import {Map} from 'immutable';
import {bindActionCreators} from 'redux';

import * as counter from './modules/counter/actions';
import * as status from './modules/status/actions';
import * as articles from './modules/articles/actions';

const actions = [counter, status, articles];

export default function mapDispatchToProps(dispatch) {
  const creators = Map()
    .merge(...actions)
    .filter(value => typeof value === 'function')
    .mapKeys(macroCaseToCamelCase)
    .toObject();

  return {
    actions: bindActionCreators(creators, dispatch),
    dispatch
  };
}

function macroCaseToCamelCase(key) {
  return key.toLowerCase().replace(/_[a-z]/g, match => match.slice(1).toUpperCase());
}