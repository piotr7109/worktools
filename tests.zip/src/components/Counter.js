import React from 'react';
import PropTypes from 'prop-types';

class Counter extends React.PureComponent {
  static propTypes = {
    counter: PropTypes.number,
    increment: PropTypes.func,
    decrement: PropTypes.func,
    toggle: PropTypes.func
  };

  render() {
    const {counter, actions: {decrement, increment, incrementAsync, toggleStatus}} = this.props;

    return (
      <div>
        <div>{counter}</div>
        <button onClick={decrement}>-</button>
        <button onClick={increment}>+</button>
        <button onClick={incrementAsync}>Async++</button>
        <button onClick={toggleStatus}>Toggle</button>
      </div>
    );
  }
}

export default Counter;