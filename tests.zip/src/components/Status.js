import React from 'react';
import PropTypes from 'prop-types';

class Status extends React.PureComponent {
  static propTypes = {
    toggled: PropTypes.bool
  };

  render() {
    const {toggled} = this.props;

    return (
      <div>
        <div style={{color: toggled ? 'green' : 'red'}}>STATUS</div>
      </div>
    );
  }
}

export default Status;