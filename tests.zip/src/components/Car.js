import React from 'react';
import PropTypes from 'prop-types';

export default class Car extends React.PureComponent {
  static propTypes = {
    article: PropTypes.object
  };

  render() {
    const {article} = this.props;

    return (
      <article style={{float: 'left', width: '50%'}}>
        <h2 style={{margin: "5px 0 0"}}>{article.get('manufacturer')} {article.get('model')}</h2>
        <div>Year: {article.get('year')}</div>
        <div>Engine: {article.get('engine')}</div>
        <div>Color: {article.get('color')}</div>
        <div>Price: {article.get('price')}</div>
      </article>
    );
  }
}