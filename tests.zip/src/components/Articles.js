import React from 'react';
import PropTypes from 'prop-types';
import serialize from 'form-serialize';
import {List} from 'immutable';

import Car from './Car';
import {LOADING_DONE, LOADING_FAILED, LOADING_IN_PROGRESS} from '../constants';

class Articles extends React.PureComponent {
  static propTypes = {
    articles: PropTypes.instanceOf(List),
    loadingStatus: PropTypes.string
  };

  getButtons() {
    const {actions: {getDataRequested}} = this.props;

    return (
      <div>
        <button onClick={getDataRequested}>Request Articles</button>
        {this.getFilterButtons()}
      </div>
    );
  }

  getFilterButtons() {
    const {loadingStatus, actions: {clearFilters}} = this.props;

    if (loadingStatus === LOADING_DONE) {
      return (
        <div>
          <button onClick={clearFilters}>All</button>
          <div>Filter by:</div>
          <form onSubmit={this.handleFilterForm}>
            {this.getNewFilterControl('Manufacturer', 'manufacturer')}
            {this.getNewFilterControl('Color', 'color')}
            {this.getNewFilterControl('Max amount', 'max_amount')}
            {this.getNewFilterControl('Min amount', 'min_amount')}
          </form>
        </div>
      );
    }
  }

  getNewFilterControl(filterAlias, filterName) {
    return (
      <div>
        {filterAlias}
        <input type="text" onChange={this.triggerSubmit} name={filterName}/>
      </div>
    );
  }

  triggerSubmit(e) {
    e.target.form.dispatchEvent(new Event("submit"));
  }

  handleFilterForm = e => {
    const {actions: {setFilters}} = this.props,
      data = serialize(e.target, {hash: true});

    e.preventDefault();
    setFilters(data);
  };

  getArticles() {
    const {loadingStatus} = this.props,
      result = {
        [LOADING_DONE]: this.getArticlesList,
        [LOADING_FAILED]: () => 'błąd',
        [LOADING_IN_PROGRESS]: () => 'ładuję, człowiek',
        default: () => ''
      };

    return result.hasOwnProperty(loadingStatus) ? result[loadingStatus].call(this) : result.default();
  }

  getArticlesList() {
    const {articles} = this.props;

    return <div>{articles.map((article, key) => <Car key={`article-${key}`} article={article}/>)}</div>;
  }

  render() {
    return (
      <div>
        {this.getButtons()}
        {this.getArticles()}
      </div>
    );
  }
}

export default Articles;