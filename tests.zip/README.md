# react-redux-example
React Redux implementation example for the blog post purpose

To run the example:

```
npm install
npm start
```