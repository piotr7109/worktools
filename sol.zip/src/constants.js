export const CARD_TYPES = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
export const CARD_COLORS = ["heart", "spade"];
export const INITIAL_CARD_STACKS = [6, 6, 6, 6, 5, 5, 5, 5, 5, 5];
export const INITIAL_CARD_DECKS = [10, 10, 10, 10, 10];
export const CARDS_COUNT = INITIAL_CARD_DECKS.sum() + INITIAL_CARD_STACKS.sum();
//104 cards