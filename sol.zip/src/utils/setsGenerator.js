import {INITIAL_CARD_STACKS, INITIAL_CARD_DECKS} from '../constants';
import Cards from './../components/Cards';

export default function generateNewSet() {
  const cards = new Cards();

  return {
    stacks: generateStacks(cards, INITIAL_CARD_STACKS),
    decks: generateStacks(cards, INITIAL_CARD_DECKS, true)
  };
}

function generateStacks(cards, stackSet, flipped = false) {
  return stackSet.reduce((stacks, rowCount) => {
    const stack = [];

    for (let i = 0; i < rowCount; i++) {
      const card = cards.getRandomCard();

      card.flipped = flipped || i === rowCount - 1;
      stack.push(card);
    }

    stacks.push(stack);

    return stacks;
  }, []);
}