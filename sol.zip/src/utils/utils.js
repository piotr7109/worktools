export const getRandomInt = max => Math.floor(Math.random() * Math.floor(max));

export const getCords = card => JSON.parse(card.dataset.cords);