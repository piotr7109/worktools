export const getNode = (selector, node = document) => node.querySelector(selector);
export const getNodes = (selector, node = document) => node.querySelectorAll(selector);

export const templateToNode = template => {
  const node = document.createElement('div');
  
  node.innerHTML = template;
  
  return node.firstChild;
};

export const cleanNode = node => {
  while (node.hasChildNodes()) {
    node.removeChild(node.lastChild);
  }
};

export const getSiblings = node => {
  const arr = [node];

  while(node = node.nextSibling) {
    arr.push(node)
  }

  return arr;
};