import {CARD_COLORS, CARD_TYPES, CARDS_COUNT} from '../constants';
import { getRandomInt } from './../utils/utils';

export default class Cards {
  constructor() {
    this.cards = [];
    while (this.cards.length < CARDS_COUNT) {
      CARD_COLORS.forEach(color =>
        CARD_TYPES.forEach((type, value) => this.cards.push({color, type, value})));
    }
  }

  getRandomCard() {
    const { cards } = this;

    return cards.splice(getRandomInt(cards.length), 1)[0];
  }
}