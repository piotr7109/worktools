
export const mousePos = {
  x: 0,
  y: 0
};

export default function bindMouseMove() {
  document.addEventListener('mousemove', event => {
    mousePos.x = event.clientX;
    mousePos.y = event.clientY;
  });
}