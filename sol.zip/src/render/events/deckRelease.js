import Events from '../Events';

export default function bindDeckRelease() {
  document.addEventListener('keydown', event => {
    if (event.keyCode === 66) {
      Events.operations.releaseDeck();
      Events.renderCallback();
    }
  });
}