import Events from '../Events';
import {getNode} from '../../utils/dom';
import {getCords} from '../../utils/utils';

const stacksNode = getNode('#root .stacks');

export default function bindCardsFlipping() {
  const cardNodes = stacksNode.querySelectorAll('.card-list .card:not(.flipped):not(.empty):last-child');

  cardNodes.forEach(card => card.addEventListener('mousedown', flipCard));
}

function flipCard(event) {
  Events.operations.flipCard(getCords(event.target).stackIndex);
  Events.renderCallback();
}