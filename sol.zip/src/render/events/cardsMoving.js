import Events from '../Events';
import {getNode, getSiblings} from '../../utils/dom';
import {getCords} from '../../utils/utils';
import {mousePos} from './mouseMove';

const stacksNode = getNode('#root .stacks');

export default function bindCardsMoving() {
  const cardNodes = stacksNode.querySelectorAll('.card.movable, .card.empty');

  cardNodes.forEach(card => {
    card.addEventListener('mousedown', handleCardPickUp);
    card.addEventListener('mouseup', handleCardDrop);
  });

  document.addEventListener('mousemove', handleCardsDrag);
  document.addEventListener('mouseup', clearDrag);
}

let draggedCards = null;

function handleCardsDrag() {
  const draggedCard = Events.selectedCard;

  if (draggedCard) {
    if (!draggedCards) {
      draggedCards = getSiblings(draggedCard);
    }

    draggedCards.forEach((card, index) => {
      card.style.left = `${mousePos.x + 1}px`;
      card.style.top = `${mousePos.y + index * 14 + 1}px`;
    })
  }
}

function clearDrag() {
  draggedCards = null;
  Events.selectedCard = null;
  Events.renderCallback();
}

function handleCardPickUp(event) {
  const {target} = event;

  if (!(Events.selectedCard || target.classList.contains('empty'))) {
    selectCard(target);
  }
}

function handleCardDrop(event) {
  if (Events.selectedCard) {
    moveCards(event.target);
  }

  Events.renderCallback();
}

function selectCard(targetCard) {
  Events.selectedCard = targetCard;
}

function moveCards(targetCard) {
  const {operations, selectedCard} = Events;
  const selectedCardData = getCords(selectedCard);
  const targetCardData = getCords(targetCard);

  operations.moveCards(selectedCardData.stackIndex, targetCardData.stackIndex, selectedCardData.index);
  Events.selectedCard = null;
}