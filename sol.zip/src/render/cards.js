import {templateToNode} from '../utils/dom';

export function createCardNode(card, index, stackIndex) {
  const cardClasses = getClasses(card);
  const cords = JSON.stringify({index, stackIndex});

  return templateToNode(
    `<li class='${cardClasses}' style='top: ${index * 14}px; left: ${stackIndex * 75}px' data-cords='${cords}'>${getCardContent(card)}</li>`
  );
}

export const getClasses = card =>
  ['flipped', 'movable', 'empty']
    .reduce((acc, key) => card[key] ? acc + ` ${key}` : acc, 'card');

export const getCardContent = card => `<span class='${card.color} card-symbol'>${card.type}</span>`;