import bindCardsMoving from './events/cardsMoving';
import bindCardsFlipping from './events/cardsFlipping';
import bindDeckRelease from './events/deckRelease';
import bindMouseMove from './events/mouseMove';

export default class Events {
  static build(opts, renderStage) {
    this.operations = opts;
    this.renderCallback = renderStage;
    this.selectedCard = null;
    bindDeckRelease();
    bindMouseMove();
  }

  static bind() {
    bindCardsMoving();
    bindCardsFlipping();
  }
}