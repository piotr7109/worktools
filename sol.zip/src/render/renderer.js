import Operations from '../game/Operations';
import {getNode, templateToNode, cleanNode} from '../utils/dom';
import {createCardNode} from './cards';
import Events from './Events';

const mainContainer = getNode('#root');
const stacksNode = getNode('.stacks', mainContainer);
const decksNode = getNode('.decks', mainContainer);
let operations;

export default function render() {
  operations = new Operations();

  Events.build(operations, renderStage);
  renderStage();
}

function renderStage() {
  clearStage();
  operations.refreshCardSet();
  renderStacks();

  Events.bind(operations, renderStage);
}

function clearStage() {
  cleanNode(stacksNode);
  cleanNode(decksNode);
}

function renderStacks() {
  const {stacks} = operations.set;

  stacks.forEach((stack, stackIndex) => {
    const listNode = templateToNode(`<ul class='card-list'></ul>`);

    stack.forEach((card, index) => listNode.appendChild(createCardNode(card, index, stackIndex)));
    stacksNode.appendChild(listNode);
  });
}