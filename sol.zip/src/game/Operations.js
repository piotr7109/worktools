import log from '../utils/logger';
import generateNewSet from '../utils/setsGenerator';

export default class Operations {
  constructor() {
    this.set = generateNewSet();
  }

  refreshCardSet() {
    this.setMovable();
  }

  setMovable() {
    const {stacks} = this.set;

    stacks.forEach(stack => {
      stack.forEach((card, index) => {
        if (card.flipped) {
          card.movable = this.checkCardMovability(stack.slice(index, stack.length));
        }
      });
    });
  }

  checkCardMovability(stack) {
    return !stack.some((card, index) => {
      const nextCard = stack[index + 1];

      return !(!nextCard || (card.value === nextCard.value + 1 && card.color === nextCard.color ));
    });
  }

  releaseDeck() {
    const {stacks, decks} = this.set;

    if (decks.length) {
      const releasedDeck = decks.pop();

      releasedDeck.forEach((card, i) => stacks[i].push(card));
      log('[DECK RELEASED]');
    }
  }

  moveCards(sourceIndex, targetIndex, cardIndex) {
    const {stacks} = this.set;
    const sourceStack = stacks[sourceIndex];
    const sourceCard = sourceStack[cardIndex];
    const targetStack = stacks[targetIndex];
    const targetCard = targetStack.last();
    const canMoveCards = targetCard.empty ||
      (targetCard.flipped && sourceCard.value === targetCard.value - 1);

    if (canMoveCards) {
      targetStack.push(...sourceStack.splice(cardIndex, sourceStack.length));
      this.handleEmptySpace(targetCard, targetStack, sourceStack);
      log(`[CARDS MOVED FROM ${sourceIndex} TO ${targetIndex}]`);
    }
  }

  handleEmptySpace(targetCard, targetStack, sourceStack) {
    if (targetCard.empty) {
      targetStack.shift();
    }

    if (sourceStack.length === 0) {
      sourceStack.push({empty: true, color: 'blank', type: 'blank'});
    }
  }

  flipCard(stackIndex) {
    this.set.stacks[stackIndex].last().flipped = true;
    log(`[CARD FLIPPED ON ${stackIndex}]`);
  }
}